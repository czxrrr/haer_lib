package com.elinc.im.haer.config;

/** 系统变量
  * @ClassName: Config
  * @Description: TODO
  * @author smile
  * @date 2014-6-17 上午9:40:11
  */
public class Config {

	//这是Bmob的ApplicationId,用于初始化操作
	public static String applicationId = "e303c6323c99096328e81e384ec4a0bd";
}
