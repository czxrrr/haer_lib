package com.elinc.im.haer.bean;

public class FaceText {
	public String text;

	public FaceText(String text) {
		super();
		this.text = text;
	}

}